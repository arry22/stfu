var banannaImage,obstacleImage,obstacleGroup,background,score,player_running,ground,monkey,banannaGroup,score;




function preload(){
player_running=loadAnimation("monkey_01.png","monkey_02.png","monkey_03.png","monkey_04.png","monkey_05.png","monkey_06.png","monkey_07.png","monkey_08.png","monkey_09.png","monkey_10.png");
bananna.loadImage("bananna.png");
obstacle.loadImage("stone.png");
background=createSprite(200,200,400,400);
background=loadImage("jungle.jpeg");
background.velocityX=-6;
ground=createSprite(200,200,5,800);
ground.visible=false;
player=createSprite(200,200,20,20);
banannaGroup=createGroup;
  banannaGroup.add(bananna);
obstacleGroup=createGroup;
score=0; 
textSize(20);
text("Score:"+score,375,375);
  
  
  
  
  



}

function draw() {
  background(220);
  createCanvas(400, 400);
if(banannaGroup.isTouching(player)){
score=score+2;
banannaGroup.destroyEach();
  
}


 if(obstacleGroup.isTouching(player)){ 
player.scale=0.2;
  

}
  drawSprites();
}
  
  
  
  
  
  














 